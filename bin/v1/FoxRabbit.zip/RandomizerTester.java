package v1;
import java.util.Random;
public class RandomizerTester {
	public static void main(String[] args){
		for(int i = 0; i<10; i++)
		System.out.println(new Random());
	}
}
